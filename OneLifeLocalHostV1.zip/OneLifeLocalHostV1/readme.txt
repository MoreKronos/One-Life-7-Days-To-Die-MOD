Only For when you locally host a server to play with friends.

WHEN A PLAYER THATS A NON SERVER HOST DIES THEY CANT REJOIN